package br.com.fitai.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitAiCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitAiCoreApplication.class, args);
	}

}
